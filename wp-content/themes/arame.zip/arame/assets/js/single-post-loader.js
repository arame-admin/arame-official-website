// Single post loading is handled via WordPress query system
// Individual posts are loaded through WordPress template system
