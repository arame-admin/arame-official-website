// Blog data is loaded dynamically from WordPress database via AJAX
// No hard-coded blog posts - all data comes from the database
