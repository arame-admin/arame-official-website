// Blog listing functionality is handled via AJAX and database queries
// No separate listing functionality needed - data comes from WordPress database
